import React, { useState } from 'react';
import { View, TextInput, Button, Text } from 'react-native';

export default function App() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState(null);
  const [classification, setClassification] = useState('');

  const calculateBMI = () => {
    const weightInKg = parseFloat(weight);
    const heightInCm = parseFloat(height) / 100;

    if (weightInKg && heightInCm) {
      const bmiValue = weightInKg / (heightInCm * heightInCm);
      setBmi(bmiValue.toFixed(2));

     if (bmiValue < 18,5) 
        setClassification('Gầy');
        if (bmiValue >= 18.5 && bmiValue <= 24.9) 
        setClassification('Bình thường');
         if (bmiValue >= 25 && bmiValue <= 29.9) 
        setClassification('Tiền béo phì');
         if (bmiValue >= 30 && bmiValue <= 34.9) 
        setClassification('Béo phì cấp độ I');
         if (bmiValue >= 35 && bmiValue <= 39.9) 
        setClassification('Béo phì cấp độ II');
      else 
        setClassification('Béo phì cấp độ III');
    };
  };

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Nhập cân nặng (kg):</Text>
      <TextInput
        style={{ height: 40, width: 200, borderColor: 'gray', borderWidth: 1, marginBottom: 20 }}
        value={weight}
        onChangeText={setWeight}
        keyboardType="numeric"
      />

      <Text>Nhập chiều cao (cm):</Text>
      <TextInput
        style={{ height: 40, width: 200, borderColor: 'gray', borderWidth: 1, marginBottom: 20 }}
        value={height}
        onChangeText={setHeight}
        keyboardType="numeric"
      />

      <Button title="Kiểm tra" onPress={calculateBMI} />

      {bmi && (
        <View>
          <Text>Chỉ số BMI: {bmi}</Text>
          <Text>Phân loại: {classification}</Text>
        </View>
      )}
    </View>
  );
}